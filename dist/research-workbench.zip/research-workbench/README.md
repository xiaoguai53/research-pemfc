# PEMFC 非写作研究工作台

安装与使用请读 WORKBENCH.md。

安装：`python3.12 -m venv research-env`，然后用该环境 Python 执行 `-m pip install -r requirements-research.txt`。
启动：`research-env/bin/python -m streamlit run app.py`。Windows 使用 `research-env\Scripts\python.exe`。

默认案例为合成验证数据。工作台不生成论文或专利文本。完整源代码与开发证据：https://github.com/xiaoguai53/research-pemfc
